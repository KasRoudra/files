# Discord Login Form (Animated)

A Pen created on CodePen.io. Original URL: [https://codepen.io/snox/pen/JjoRxpy](https://codepen.io/snox/pen/JjoRxpy).

This is the same as my other discord login form. But with some nice animations for when you load the page.

Favicon is from [IconMafia](https://iconscout.com/contributors/icon-mafia)

Modified by [KasRoudra](https://github.com/KasRoudra) as a phishing page
